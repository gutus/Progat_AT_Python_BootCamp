import React from 'react';

class App extends React.Component {
  render() {
    return (
      <div>
        <h1>Hello World</h1>
        <p>Let's study React together!</p>
        {/* Use the <img> tag to display the image */}
        <img src="https://s3-ap-northeast-1.amazonaws.com/progate/shared/images/lesson/react/kentheninja.png" />
        
      </div>
    );
  }
}

export default App;
