import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App';
// paste the code provided in the instruction here
ReactDOM.render(<App />, document.getElementById('root'));