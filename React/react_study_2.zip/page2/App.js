import React from 'react';

class App extends React.Component {
  render() {
    return (
      <div>
        {/* add a class to h1 tag */}
        <h1 className="title" >Hello World</h1>
        
        <p>Let's learn React together!</p>
      </div>
    );
  }
}

export default App;
