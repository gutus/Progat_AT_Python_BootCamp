let number = 7;
console.log(number);

// Add 3 to the value of the number variable
number += 3;

console.log(number);

// Divide the value of the number variable by 2
number = number / 2;

console.log(number);
