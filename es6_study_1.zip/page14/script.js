const password = "kentheninja";

// When the value of password is "kentheninja", output "Signed in successfully"
if (password === "kentheninja"){
  console.log("Signed in successfully");
}


// When the value of password is not "kentheninja", output "Wrong password"
if (password !== "kentheninja"){
  console.log("Wrong password");
}

