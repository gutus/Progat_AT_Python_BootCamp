const name = "Ken the Ninja";
const age = 14;

// Output the string "My name is ____"
console.log(`My name is ${name}`);

// Output the string "Today I am ____ years old"
console.log(`Today I am ${age} years old`);
