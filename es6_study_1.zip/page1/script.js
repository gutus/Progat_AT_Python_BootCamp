console.log("Welcome to ES6 Study I!");
console.log("Let's learn with Ken the Ninja!");
