# Print 7 as an integer
print(7)

# Print the sum of 9 and 3
print(9+3)

# Print '9 + 3' as a string
print("9 + 3")