-- get the id and number of units sold of the top 5 most purchased items
SELECT item_id, COUNT(user_id) AS "COUNT(*)"
FROM sales_records
GROUP BY item_id 
ORDER BY COUNT(user_id) DESC
LIMIT 5;