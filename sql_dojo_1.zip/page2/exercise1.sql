-- get the average age of all users
SELECT AVG(age)
FROM users