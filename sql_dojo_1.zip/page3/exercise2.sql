-- get the name and price of every product in descending order by price
SELECT name, price
FROM items
ORDER BY price DESC