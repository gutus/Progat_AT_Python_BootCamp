-- get the names of every product without including duplicates
SELECT DISTINCT name
FROM items