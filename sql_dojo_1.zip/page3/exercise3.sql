-- get all rows that contain the string "shirt"
SELECT *
FROM items
WHERE name LIKE "%shirt%"