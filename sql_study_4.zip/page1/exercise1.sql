-- add data to the students table
INSERT INTO students ( name, course)
VALUES ( "Kate", "Java");
-- do not delete the following query
select * from students;
