# Define the MenuItem class
class MenuItem:
        pass