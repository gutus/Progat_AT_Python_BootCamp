fruits = {'apple': 'manzana', 'orange': 'naranja', 'grape': 'uva'}

# With a for loop, print '____ is ____ in Spanish'
for fruit_key in fruits:
    print((fruit_key)+" is "+(fruits[fruit_key]) +" in Spanish")
