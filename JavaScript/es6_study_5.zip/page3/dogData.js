// Make the dog constant accessible in this file
import Dog from "./dog";

const dog = new Dog("Leo", 4, "Chihuahua");

// Export the constant dog
export default dog;
