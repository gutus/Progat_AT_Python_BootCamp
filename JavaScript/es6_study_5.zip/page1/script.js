// Move the Animal class definition to animal.js and remove it below


// Move the Dog class definition to dog.js and remove it below


// Leave the code below because it's not part of the Animal or Dog classes
const dog = new Dog("Leo", 4, "Chihuahua");
dog.info();

