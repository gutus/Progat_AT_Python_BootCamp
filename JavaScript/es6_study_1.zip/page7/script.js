// Declare the length variable
let length= 5;

// Output the value of the length variable
console.log(length);

// Use the length variable to output the circle's area
console.log(length * length * 3);
