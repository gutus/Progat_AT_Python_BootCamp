class Animal {
}

// Assign the Animal class instance to the animal constant
const animal= new Animal();

// Output the value of the animal constant
console.log(animal);
