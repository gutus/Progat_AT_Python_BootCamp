// Complete the for loop
for (let number =1; number <= 100; number++) {
  
  // Use an if statement to print "Multiple of 3" when number is a multiple of 3 
  if (number % 3 === 0) {
    console.log("Multiple of 3");
  }else {console.log(number)
  }
}
