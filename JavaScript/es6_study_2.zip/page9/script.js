const animals = ["dog", "cat", "sheep", "rabbit", "monkey", "tiger", "bear", "elephant"];

// Use the length property to print the number of elements in the array
console.log(animals.length);

// Use the length property to replace the condition
for (let i = 0; i < animals.length; i++) {
  console.log(animals[i]);
}
