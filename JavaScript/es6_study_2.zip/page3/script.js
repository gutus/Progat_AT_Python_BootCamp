// Use a for loop to print numbers from 1 to 100
for (let number = 1; number <= 100; number++){
  console.log(number);
};
