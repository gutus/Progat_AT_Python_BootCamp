// Declare the character constant and assign the provided object to it
const character={name: "Ken the Ninja", age: 14};

// Print the value of character
console.log(character);
