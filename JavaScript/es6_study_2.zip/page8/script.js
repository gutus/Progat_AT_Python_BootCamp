const animals = ["dog", "cat", "sheep"];

// Use a for loop to print the array elements in order in the console
for (let i =0; i < 3; i++){
  console.log(animals[i]);
}
