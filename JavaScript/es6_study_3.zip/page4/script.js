// Add the name parameter to the function
const greet = (name) => {
  // Print the message "Hello, ____"
  console.log(`Hello, ${name}`);
};

// Call the greet function with "Master Wooly" as the argument
greet("Master Wooly");
