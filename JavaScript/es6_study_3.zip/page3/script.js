// Assign an arrow function to the greet constant
const greet= () => {
  console.log("Hello!");
}



// Call the greet function
greet();
