-- get the highest price of all the values in the price column

SELECT MAX(price)
FROM purchases;