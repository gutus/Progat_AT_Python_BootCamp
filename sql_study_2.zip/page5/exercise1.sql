-- get the number of rows in the name column from the purchases table

SELECT COUNT(name)
FROM purchases;