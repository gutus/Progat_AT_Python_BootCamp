-- get the sum total of the price column 

SELECT SUM(price)
FROM purchases;
