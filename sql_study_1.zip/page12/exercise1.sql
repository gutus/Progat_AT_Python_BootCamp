-- after "FROM purchases" add code to put rows in descending order by the "price" column

SELECT *
FROM purchases
WHERE price
ORDER BY price DESC; 