-- get the "price" column from the "purchases" table
SELECT price FROm purchases;

