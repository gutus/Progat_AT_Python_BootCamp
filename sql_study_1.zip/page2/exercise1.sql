-- get the "name" column from the "purchases" table

SELECT name from purchases;