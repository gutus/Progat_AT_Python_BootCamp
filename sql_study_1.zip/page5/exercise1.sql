-- after "FROM purchases" add code to get rows that have "10" in the "price" column

SELECT *
FROM purchases
WHERE price = 10;