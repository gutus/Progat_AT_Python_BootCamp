-- get the "name" and "price" columns from the "purchases" table

SELECT name, price FROM purchases;